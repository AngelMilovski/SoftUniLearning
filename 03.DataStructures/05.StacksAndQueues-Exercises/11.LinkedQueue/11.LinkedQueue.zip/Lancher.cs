﻿using System;
using System.Collections.Generic;


public class Launcher
{
    public static void Main()
    {
        var test = new LinkedQueue<int>();
        test.Enqueue(1);
        test.Enqueue(2);
        
        test.Enqueue(3);
        foreach (var item in test)
        {
            Console.WriteLine(item);
        }
        var result = test.ToArray();
        
    }
}