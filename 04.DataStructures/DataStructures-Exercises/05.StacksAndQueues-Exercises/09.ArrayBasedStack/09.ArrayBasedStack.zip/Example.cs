﻿public class Example
{
    public static void Main()
    {
        
    }
}