﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Launcher
{
    public static void Main()
    {
        var test = new LinkedStack<int>();

        test.Push(1);
        test.Push(2);
        test.Push(3);
        var result = test.Pop();
        test.Push(3);
        foreach (var item in test)
        {
            Console.WriteLine(item);
        }
    }
}