﻿using System;

public class Program
{
    public static void Main()
    {
    }
}